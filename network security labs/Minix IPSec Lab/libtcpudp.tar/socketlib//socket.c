/*
   Library to handle TCPIP interface (BSD sockets emulation).

   version 0.2.0

   October 2003 (v0.1)
   November 2003 (v0.1.1)
   December 2003 (v0.2.0)

   NOTES: this version ONLY supports TCP ports to be defined.

*/

#define _minix

#if defined(__minix) || defined (_MINIX)

#include <stdio.h>
#include <stdlib.h>
#include <socket.h>
#include <signal.h>

/* #define	 DEBUG   */
/* #define  SOCK_TIMEOUT */

/*
   mnx_socket allocates a channel to the communication device.
*/
int mnx_socket(int proto)
{
	char *device;
	int fd;

	if (proto == IPPROTO_UDP) {   /* UDP protocol */
	   device = (char *)getenv("UDP_DEVICE");
	   if (device == NULL) device = UDP_DEVICE;
#ifdef DEBUG
	   fprintf(stderr,"mnx_socket: UDP socket\n");
#endif
	   }
	else {  /* we asume any other thing as TCP */
	   device = (char *)getenv("TCP_DEVICE");
	   if (device == NULL) device = TCP_DEVICE;
#ifdef DEBUG
	   fprintf(stderr,"mnx_socket: TCP socket\n");
#endif
	   }
	if ((fd = open(device, O_RDWR)) < 0) {
#ifdef DEBUG
	   fprintf(stderr,"mnx_socket: error %d\n", errno);
#endif
	   return(fd);
	   }

#ifdef DEBUG
	fprintf(stderr,"mnx_socket: fd %d\n", fd);
#endif
	return (fd);
}

/*
   mnx_connect use the channel allocated, remote IP and PORT and issue
   a conection.
*/
int mnx_connect(int fd, struct sockaddr *addr)
{
#ifdef SOCK_TIMEOUT
	char *timeoutstr;
#endif
	unsigned int timeout;
	nwio_tcpconf_t tcpconf;
	nwio_tcpcl_t tcpconnopt;

#ifdef SOCK_TIMEOUT
	/* timeout to avoid hang forever in connections */
	timeoutstr = (char *) getenv("IP_TIMEOUT");
	if (timeoutstr == NULL) timeoutstr = IP_TIMEOUT;
	timeout= (unsigned int)atoi(timeoutstr);
#endif
#ifdef DEBUG
	fprintf(stderr,"mnx_connect: fd %d", fd);
#ifdef SOCK_TIMEOUT
	fprintf(stderr,", timeout %d\n", timeout);
#else
	fprintf(stderr,"\n");
#endif
#endif
#ifdef SOCK_TIMEOUT
        signal(SIGALRM, mnx_alarm); /* alarm signals here */
        alarm(timeout);  /* timeout */
#endif
	tcpconf.nwtc_flags= NWTC_LP_SEL | NWTC_SET_RA | NWTC_SET_RP;
	tcpconf.nwtc_remaddr= addr->sin_addr.s_addr;
	tcpconf.nwtc_remport= addr->sin_port;
#ifdef DEBUG
	fprintf(stderr,"mnx_connect: ioctl conf remote %s,%u.\n",
			inet_ntoa(tcpconf.nwtc_remaddr),
			ntohs(tcpconf.nwtc_remport));
#endif
	if (ioctl(fd, NWIOSTCPCONF, &tcpconf) < 0) return -1;
#ifdef DEBUG
	fprintf(stderr,"mnx_connect: ioctl connection\n");
#endif
	tcpconnopt.nwtcl_flags= 0;
	if (ioctl(fd, NWIOTCPCONN, &tcpconnopt) < 0) return -1;

#ifdef SOCK_TIMEOUT
	alarm(0);  /* disable timeout */
#endif
#ifdef DEBUG
	fprintf(stderr,"mnx_connect: fd %d connected ok\n", fd);
#endif
	return 0;
}

/*
   mnx_select is dummy, for compatibility.
*/
int mnx_select(fd_set *pset)
{
	FD_ZERO(pset);		/* Never I/O on a specific fd. */
	return 1;		/* Always assume I/O can be done. */
}

/*
   mnx_alarm is used to avoid hanging connections.
*/
void mnx_alarm(int sig)
{
    signal(SIGALRM, mnx_alarm); /* alarm signals here */
}

/*
   mnx_accept waits remote conections.
*/
int mnx_accept(int fd, struct sockaddr *addr)
{
	int result, chan;
	nwio_tcpcl_t tcplistenopt;
	nwio_tcpconf_t tcpconf, tcpconf2;

/* we first allocate a new channel and duplicate settings from fd */
        if ((chan = mnx_socket(IPPROTO_TCP)) < 0) {
#ifdef DEBUG
	   fprintf(stderr,"mnx_accept: new channel mnx_socket error %d\n", errno);
#endif
	   return(-1);
	   }

/* now we copy settings to new channel */
	if (ioctl(fd, NWIOGTCPCONF, &tcpconf)==-1) {
#ifdef DEBUG
	   fprintf(stderr,"mnx_accept: error %d getting info from fd %d\n", errno, fd);
#endif
	   return -1;
	   }
 	/* force configuration  */
	tcpconf.nwtc_flags |= NWTC_SHARED;  
	if (ioctl(fd, NWIOSTCPCONF, &tcpconf)==-1) {
#ifdef DEBUG
	   fprintf(stderr,"mnx_accept: error %d setting info to fd %d\n", errno, chan);
#endif
	   return -1;
	   }

	if (ioctl(chan, NWIOSTCPCONF, &tcpconf)==-1) {
#ifdef DEBUG
	   fprintf(stderr,"mnx_accept: error %d setting info to chan %d\n", errno, chan);
#endif
	   return -1;
	   }

#ifdef DEBUG
	fprintf(stderr,"mnx_accept: chan %d wait for connections.\n", chan);
#endif
	tcplistenopt.nwtcl_flags= 0;
	while ((result= ioctl(chan, NWIOTCPLISTEN, &tcplistenopt)) == -1) {
	   if (errno != EAGAIN)
	      break;
	   sleep(1); 
	   }

	if (result == -1) {
#ifdef DEBUG
	   fprintf(stderr,"mnx_accept: error listen %d\n", errno);
#endif
	   return(-1);
	   }

	if (ioctl(chan, NWIOGTCPCONF, &tcpconf2)==-1) {
#ifdef DEBUG
		fprintf(stderr,"mnx_accept: error %d getting info %d\n", errno, chan);
#endif
		return -1;
		}
#ifdef DEBUG
	fprintf(stderr,"mnx_accept: accept successfull channel %d\n", chan);
	fprintf(stderr, "mnx_accept: from %s, %u",
			inet_ntoa(tcpconf2.nwtc_remaddr),
			ntohs(tcpconf2.nwtc_remport));
	fprintf(stderr," for %s, %u\n",
			inet_ntoa(tcpconf2.nwtc_locaddr),
			ntohs(tcpconf2.nwtc_locport));
#endif
	/* filling struct */
	addr->sin_addr.s_addr = tcpconf2.nwtc_remaddr;
	addr->sin_port = tcpconf2.nwtc_locport;
	return (chan);
}

/*
   mnx_listen, set RST Delay (if we can)
*/
int mnx_listen(int fd)
{
	nwio_tcpopt_t tcpopt;

#ifdef DEBUG
	fprintf(stderr,"mnx_listen: setting opt fd %d.\n", fd);
#endif
	if (ioctl(fd, NWIOGTCPOPT, &tcpopt)==-1) {
#ifdef DEBUG
	   fprintf(stderr,"mnx_listen: fd %d get error %d\n", fd, errno);
#endif
/*	   return (-1); */
	   tcpopt.nwto_flags == 0;
	   }

	tcpopt.nwto_flags |= NWTO_DEL_RST;
	if (ioctl(fd, NWIOSTCPOPT, &tcpopt)==-1) {
#ifdef DEBUG
	   fprintf(stderr,"mnx_listen: fd %d set error %d\n", fd, errno);
#endif
	   return (-1);
	   }
#ifdef DEBUG
	fprintf(stderr,"mnx_listen: fd %d, ok.\n", fd);
#endif

	return 0;  /* no problems */
}

/*
   mnx_bind allocates the port for accepting incoming connections.
*/
int mnx_bind(int fd, struct sockaddr *addr)
{
	nwio_tcpconf_t tcpconf;

#ifdef DEBUG
	fprintf(stderr,"mnx_bind: configuring port fd %d.\n", fd);
#endif
	tcpconf.nwtc_flags = NWTC_UNSET_RP | NWTC_EXCL; /* no remote port specified */
	tcpconf.nwtc_remaddr = 0L;
	tcpconf.nwtc_remport = htons(0);
	tcpconf.nwtc_locport = htons(0);
	/* check for remote IP */
	if (addr->sin_addr.s_addr == INADDR_ANY) {
	   tcpconf.nwtc_flags |= NWTC_UNSET_RA;
#ifdef DEBUG
   	   fprintf(stderr,"mnx_bind: ANY remote address.\n");
#endif
           }
        else {
	   tcpconf.nwtc_remaddr = addr->sin_addr.s_addr;
	   tcpconf.nwtc_flags |= NWTC_SET_RA;
#ifdef DEBUG
   	   fprintf(stderr,"mnx_bind: remote address %s.\n", inet_ntoa(addr->sin_addr.s_addr));
#endif
	   }
	/* local port where to listen */
	if (addr->sin_port > 0) {
	   tcpconf.nwtc_flags |= NWTC_LP_SET;
	   tcpconf.nwtc_locport= addr->sin_port;
#ifdef DEBUG
   	   fprintf(stderr,"mnx_bind: local port %d.\n", ntohs(addr->sin_port));
#endif
           }
        else {
	   tcpconf.nwtc_flags |= NWTC_LP_SEL;
#ifdef DEBUG
   	   fprintf(stderr,"mnx_bind: local port auto-select.\n");
#endif
	   }

	if (ioctl(fd, NWIOSTCPCONF, &tcpconf) < 0) return -1;

#ifdef DEBUG
   	fprintf(stderr,"mnx_bind: success.\n");
#endif
	return 0;
}

/*
   mnx_getsockname...
*/
int mnx_getsockname(int fd, struct sockaddr *addr)
{
	nwio_tcpconf_t tcpconf;

#ifdef DEBUG
	fprintf(stderr,"mnx_getsockname: ioctl fd %d.\n", fd);
#endif
	if (ioctl(fd, NWIOGTCPCONF, &tcpconf)==-1) {
#ifdef DEBUG
	   fprintf(stderr,"mnx_getsockname: error %d\n", errno);
#endif
	   return (-1);
	   }
#ifdef DEBUG
	fprintf(stderr, "mnx_getsockname: from %s, %u",
			inet_ntoa(tcpconf.nwtc_remaddr),
			ntohs(tcpconf.nwtc_remport));
	fprintf(stderr," for %s, %u\n",
			inet_ntoa(tcpconf.nwtc_locaddr),
			ntohs(tcpconf.nwtc_locport));
#endif
	addr->sin_addr.s_addr = tcpconf.nwtc_remaddr ;
	addr->sin_port = tcpconf.nwtc_locport;

	return 0;
}

/*
   mnx_setsockopt...
*/
int mnx_setsockopt(int fd)
{
#ifdef DEBUG
	fprintf(stderr,"mnx_setsockopt: fd %d.\n", fd);
#endif
}

/*
   mnx_getsockopt...
*/
int mnx_getsockopt(int fd)
{
#ifdef DEBUG
	fprintf(stderr,"mnx_getsockopt: fd %d.\n", fd);
#endif
}

/*
   gettimeofday() is commonly used in some tools using network
   information.

   This is a workarround for Minix.

*/

void gettimeofday(timeval_t *tv)
{
  struct tms buf; /* this give us various times in ticks */
  clock_t t, r;      /* time since boot in ticks */
  
  t = times(&buf);  /* we ignore our statistics */
  tv->tv_sec = t / CLOCKS_PER_SEC;  /* ticks to seconds */
  r = t % CLOCKS_PER_SEC;  /* remain ticks */
  tv->tv_usec = (long) (((r * 1000) / 60) * 1000); /* set to microseconds */
}

/*
   mnx_shutdown TCP channel
*/
int mnx_shutdown(int fd)
{
#ifdef DEBUG
   fprintf(stderr,"mnx_shutdown: channel fd %d.\n", fd);
#endif
   /* only supports full channel shutdown */
  if (ioctl(fd, NWIOTCPSHUTDOWN, 0) < 0) return -1;
  return 0;
}

#endif
