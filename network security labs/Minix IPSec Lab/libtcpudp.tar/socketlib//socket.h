/*
   Library to handle TCPIP interface (BSD sockets emulation).
   Include header.

   version 0.2.0

   October 2003 (v0.1)
   November 2003 (v0.1.1)
   December 2003 (v0.2.0)

   NOTES: this version ONLY supports TCP ports to be defined.

*/

#ifndef _SOCKET_H
#define _SOCKET_H 

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <minix/config.h>
#include <string.h>
#include <errno.h>
#include <sys/times.h>
#include <time.h>
#include <limits.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>

#include <net/gen/in.h>
#include <net/gen/inet.h>
#include <net/gen/netdb.h>
#include <net/gen/socket.h>
#include <net/gen/tcp.h>
#include <net/gen/tcp_hdr.h>
#include <net/gen/tcp_io.h>
#include <net/hton.h>
#include <net/netlib.h>

#define IP_TIMEOUT "30"	/* seconds */

typedef unsigned int socklen_t;

struct in_addr { u_long s_addr; };

struct sockaddr_in {
	struct in_addr sin_addr;
	u_short sin_port;
	u_short sin_family;
};

#define sockaddr sockaddr_in

#define INADDR_ANY	HTONL(0xFFFFFFFF)

#define socket(a, b, c)			mnx_socket(c)  /* IPPROTO_TCP or _UDP) */
#define connect(fd, addr, len)		mnx_connect(fd, addr)
#define select(a, pset, c, d, e)	mnx_select(pset)
#define accept(fd, addr, len)		mnx_accept(fd, addr)
#define listen(fd, l)			mnx_listen(fd)
#define bind(fd, addr, len)		mnx_bind(fd, addr)
#define getsockname(fd, addr, len)	mnx_getsockname(fd, addr)
#define setsockopt(fd, b, c, d, e)	mnx_setsockopt(fd)
#define getsockopt(fd, b, c, d, e)	mnx_getsockopt(fd)
#define shutdown(fd, how)		mnx_shutdown(fd)

void mnx_alarm(int);
int mnx_socket(int proto);
int mnx_connect(int fd, struct sockaddr *addr);
int mnx_select(unsigned int *pset);
int mnx_accept(int fd, struct sockaddr *addr);    	
int mnx_listen(int fd);					
int mnx_bind(int fd, struct sockaddr *addr);    	
int mnx_getsockname(int fd, struct sockaddr *addr);    	
int mnx_getsockopt(int fd);    	
int mnx_setsockopt(int fd);    	
int mnx_shutdown(int fd);

#ifndef __minix_vmd
typedef struct timeval { long tv_sec, tv_usec; } timeval_t;
#endif

/*
  MACROS FOR MANIPULATING MASKS FOR SELECT()
 */
#ifndef FD_SET
typedef unsigned int fd_set;
#define FD_SET(fd,pmask) (*(pmask)) |=  (1<<(fd))
#define FD_CLR(fd,pmask) (*(pmask)) &= ~(1<<(fd))
#define FD_ZERO(pmask)   (*(pmask))=0
#define FD_ISSET(fd,pmask) (*(pmask) & (1<<(fd)))
#define FD_SETSIZE 32
#endif  /* !FD_SET */

#define SOL_SOCKET 1
#define SO_ERROR 2
#define PF_INET AF_INET

/* definitions for shutdown command */
#define SHUT_RD	  0
#define SHUT_WR   1
#define SHUT_RDWR 2

#define syslog(a,b,c,d)	fprintf(stderr,b)

#endif /* _SOCKET_H */
