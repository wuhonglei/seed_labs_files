/*
talker.c and listener.c are simple communication programs using udp.
listener.c is to listen a udp port and display incoming messages sent by talker.c;
talker.c try to send messages to listener in the following format:

usage: talker listener message 
	    talker 192.168.163.122 "this is test message"

to compile files:
cc talker.c -o talker
cc listener.c -o listener
*/

#include <sys/types.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <signal.h>
#include <assert.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/asynchio.h>
#include <net/hton.h>
#include <net/netlib.h>
#include <net/gen/in.h>
#include <net/gen/inet.h>
#include <net/gen/nameser.h>
#include <net/gen/resolv.h>
#include <net/gen/netdb.h>
#include <net/gen/socket.h>
#include <net/gen/udp.h>
#include <net/gen/udp_hdr.h>
#include <net/gen/udp_io.h>

#define MYPORT 4950 /* the port users will be sending to */  
#define MAXBUFLEN 100  

int main(int argc, char * argv[])  
{  
char buf[MAXBUFLEN];  
char *udp_device;
nwio_udpopt_t udpopt;
int udp_fd;
udpport_t listen_port;
int s, i;
udp_io_hdr_t *udp_io_hdr;

/*try to get a valid udp device, if can not find in envirnment setting,
    use default one UDP_DEVICE*/   
   if((udp_device = getenv("UDP_DEVICE")) == (char *)NULL) 
   	udp_device = UDP_DEVICE;

/*open udp device to get udp file descriptor*/
   if((udp_fd = open(udp_device, O_RDWR)) < 0) {
   	fprintf(stderr, "listener: Could not open %s: %s\n",
   		udp_device, strerror(errno));
   	return(-1);
   }
/*set listenning port in network order*/
   listen_port = htons(MYPORT);;

/*set udp operation flags, which determine how to establish a udp connection
   the flag meaning is explained in 
   http://www.cs.vu.nl/pub/minix/2.0.0/wwwman/man4/ip.4.html*/
   udpopt.nwuo_flags = NWUO_NOFLAGS;
   udpopt.nwuo_flags |= NWUO_COPY | NWUO_LP_SET | NWUO_EN_LOC;
   udpopt.nwuo_flags |= NWUO_DI_BROAD | NWUO_RP_ANY | NWUO_RA_ANY;
   udpopt.nwuo_flags |= NWUO_RWDATALL | NWUO_DI_IPOPT;
   udpopt.nwuo_locport = listen_port;

/*using ioctl system call to set udp operation flags in kernel*/
   s = ioctl(udp_fd, NWIOSUDPOPT, &udpopt);
   if(s < 0) {
   	perror("listener: ioctl NWIOSUDPOPT");
   	close(udp_fd);
   	return(-1);
   }
/*try to get message from other mechine. If get it, quit the loop; 
   if not, waiting forever*/
while(1){
/*using read system call to get data*/
   s = read(udp_fd, buf, sizeof(buf));
/*if fail to get, try to read again, waiting forever*/
   if(s < 0) {
   	fprintf(stderr, "listener: did not get data\n");
   	continue;
   }
   buf[s]='\0';

   if(s < sizeof(udp_io_hdr_t)) {
   fprintf(stderr, "listener Packet size %d is smaller the udp_io_hdr\n", s);
   return(-1);
   }
/*if get data, it is in the following format:
   udp_io_header | data
   to get data, need to delete the udp_io_header*/ 
   udp_io_hdr = (udp_io_hdr_t *)buf;
   s = s - sizeof(udp_io_hdr_t);

   if(udp_io_hdr->uih_data_len != s) {
	fprintf(stderr, "listener: Size mismatch Packet %d  Udp Data %d\n",
		s, udp_io_hdr->uih_data_len);
	return(-1);
   }

   printf("listener: from %s, %u \n",
			inet_ntoa(udp_io_hdr->uih_src_addr),
			ntohs(udp_io_hdr->uih_src_port));
   printf("message: %s\n", (buf + sizeof(udp_io_hdr_t)));
   break;
}
close(udp_fd);
return 0;
}


