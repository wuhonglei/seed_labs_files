/*
talker.c and listener.c are simple communication programs using udp.
listener.c is to listen a udp port and display incoming messages sent by talker.c;
talker.c try to send messages to listener in the following format:

usage: talker listener message 
	    talker 192.168.163.122 "this is test message"

to compile files:
cc talker.c -o talker
cc listener.c -o listener
*/

#include <sys/types.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <signal.h>
#include <assert.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/asynchio.h>
#include <net/hton.h>
#include <net/netlib.h>
#include <net/gen/in.h>
#include <net/gen/inet.h>
#include <net/gen/nameser.h>
#include <net/gen/resolv.h>
#include <net/gen/netdb.h>
#include <net/gen/socket.h>
#include <net/gen/udp.h>
#include <net/gen/udp_hdr.h>
#include <net/gen/udp_io.h>

#define REMOTPORT 		4950 /* the port users will be sending to */  
#define MAXDATASIZE		100

int main(int argc, char *argv[])  
{  
	int udp_fd;  
	int s, i;
	char *udp_device;
	nwio_udpopt_t udpopt;
	struct hostent *he;  
	int numbytes;  
	char buf[MAXDATASIZE];

	if (argc != 3) {  
		fprintf(stderr,"usage: talker hostname message\n");  
		exit(1);  
	}  

 /* get the host info, to convert listener's hostname or ip address
     into network order, saving in he->h_addr*/  
	if ((he=gethostbyname(argv[1])) == NULL) {
		perror("gethostbyname");  
		exit(1);  
	}  

/*try to get a valid udp device, if can not find in envirnment setting,
    use default one UDP_DEVICE*/   
	if((udp_device = getenv("UDP_DEVICE")) == (char *)NULL)
		udp_device = UDP_DEVICE;

/*open udp device to get udp file descriptor*/
	if((udp_fd = open(udp_device, O_RDWR)) < 0) {
		fprintf(stderr, "talker: Could not open %s: %s\n",
			udp_device, strerror(errno));
		return(-1);
	}

/*set udp operation flags, which determine how to establish a udp connection
   the flag meaning is explained in 
   http://www.cs.vu.nl/pub/minix/2.0.0/wwwman/man4/ip.4.html*/
	udpopt.nwuo_flags = NWUO_NOFLAGS;
	udpopt.nwuo_flags |= NWUO_COPY | NWUO_LP_SEL | NWUO_EN_LOC;
	udpopt.nwuo_flags |= NWUO_DI_BROAD | NWUO_RP_SET | NWUO_RA_SET;
	udpopt.nwuo_flags |= NWUO_RWDATONLY | NWUO_DI_IPOPT;
	/*set remote listener's ip address and port*/
	udpopt.nwuo_remaddr = *((ipaddr_t *)he->h_addr);
	udpopt.nwuo_remport = htons(REMOTPORT);;

/*using ioctl system call to set udp operation flags in kernel*/
	s = ioctl(udp_fd, NWIOSUDPOPT, &udpopt);
	if(s < 0) {
		perror("talker: ioctl NWIOSUDPOPT");
		close(udp_fd);
		return(-1);
	}

	strcpy(buf, argv[2]);
	numbytes = strlen(buf);
	
/*using write system call to send data to listener*/
	s = write(udp_fd, buf, numbytes);
	if(s < 0) {
		perror("talker: write error in sendrequest");
		return(-1);
	}

	if(s != numbytes) {
		fprintf(stderr, "talker: sendrequest size mismatch %d %d\n", s, sizeof(buf));
		return(-1);
	}
	close(udp_fd);
	return(0);
}

