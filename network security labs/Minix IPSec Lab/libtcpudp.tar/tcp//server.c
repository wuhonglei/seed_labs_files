/*
server.c and client.c are simple TCP communication programs;
server is always listening on a tcp port, if get a new connection 
request from client, message "Hello, world!" is sent to client.

usage: client ip/hostname

compile:
since they use emulation socket lib, please compile socketlib first,
then compile as following:

cc server.c -o server -l socket
cc client.c -o client -l socket

*/

#include <sys/types.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <socket.h>

#include <net/hton.h>
#include <net/netlib.h>
#include <net/gen/netdb.h>
#include <net/gen/in.h>
#include <net/gen/inet.h>
#include <net/gen/route.h>
#include <net/gen/socket.h>
#include <net/gen/ip_io.h>

#define MYPORT 4950 /* the port users will be sending to */  
#define MAXBUFLEN 100  
main(int argc, char * argv[])  
{  
	int sockfd, new_fd;  
	struct sockaddr_in my_addr; /* my address information */  
	struct sockaddr_in their_addr; /* connector's address information */  
	int addr_len, numbytes, sin_size;  
	char buf[MAXBUFLEN] = "Hello, world!\n"; 

	if ((sockfd = socket(AF_INET, 0, 0)) == -1) {  
		fprintf(stderr, "socket");  
		exit(1);  
	}  

		my_addr.sin_family = AF_INET; /* host byte order */  
		my_addr.sin_port = htons(MYPORT); /* short, network byte order */  
		my_addr.sin_addr.s_addr = INADDR_ANY; /* auto-fill with my IP */  

	/*bind socket with own ip and port*/
	if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1) {  
		fprintf(stderr, "bind");  
		exit(1);  
	} 
	/*listening on the port*/
	if (listen(sockfd, 0) == -1) {  
		fprintf(stderr, "listen");  
		exit(1);  
	}  

	while(1) { 
		sin_size = sizeof(struct sockaddr_in);  
		/*accept connections from other machine, using new_fd to establish
		   connection, while sockfd is still waiting*/
		if ((new_fd = accept(sockfd, (struct sockaddr *)&their_addr,   
			&sin_size)) == -1) {  
			fprintf(stderr, "accept");  
			continue;  
		}  
		printf("server: got connection from %s\n",  
		inet_ntoa(their_addr.sin_addr.s_addr));  
		
		/* this is the child process */  
		if (!fork()) { 
			/* to write data in buf to the remote client*/
			if (write(new_fd, buf, strlen(buf)) == -1){  
				fprintf(stderr, "send");  
				close(new_fd);  
				exit(0); 
			}
		}  
		close(new_fd); /* parent doesn't need this */  
	}
}  

