/*
server.c and client.c are simple TCP communication programs;
server is always listening on a tcp port, if get a new connection 
request from client, message "Hello, world!" is sent to client.

usage: client ip/hostname

compile:
since they use emulation socket lib, please compile socketlib first,
then compile as following:

cc server.c -o server -l socket
cc client.c -o client -l socket

*/

#include <sys/types.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <socket.h>

#include <net/hton.h>
#include <net/netlib.h>
#include <net/gen/netdb.h>
#include <net/gen/in.h>
#include <net/gen/inet.h>
#include <net/gen/route.h>
#include <net/gen/socket.h>
#include <net/gen/ip_io.h>

#define PORT 4950 /* the port users will be sending to */  
#define MAXDATASIZE 100  

int main(int argc, char *argv[])  
{  
	int sockfd, numbytes;  
	char buf[MAXDATASIZE];  
	struct hostent *he;  
	struct sockaddr_in their_addr; /* connector's address information */  
	if (argc != 2) {  
		fprintf(stderr,"usage: client hostname\n");  
		exit(1);  
	}  

	/* get the host info, to convert hostname or ip address (argv[1]) to
	    the network order, and saving in he->h_addr*/  
	if ((he=gethostbyname(argv[1])) == NULL) { 
		fprintf(stderr,"gethostbyname");  
		exit(1);  
	}  

	/*create a socket, actually call mnx_socket(0), 0 here means TCP*/
	if ((sockfd = socket(AF_INET, 0, 0)) == -1) {  
		fprintf(stderr, "socket");  
		exit(1);  
	}  

	their_addr.sin_family = AF_INET; /* host byte order */  
	their_addr.sin_port = htons(PORT); /* short, network byte order */  
	their_addr.sin_addr = *((struct in_addr *)he->h_addr);  

	/*connect socket to remote server*/
	if (connect(sockfd, (struct sockaddr *)&their_addr,sizeof(struct	\
		sockaddr)) == -1) {  
		fprintf(stderr, "connect");  
		exit(1);  
	}  

	/*try to read data from socket file descriptor*/
	if ((numbytes=read(sockfd, buf, MAXDATASIZE)) == -1) {  
		fprintf(stderr, "recv");  
		exit(1);  
	}  
	buf[numbytes] = '\0';  
	printf("Received: %s",buf);  
	close(sockfd);  
	return 0;  
}  

